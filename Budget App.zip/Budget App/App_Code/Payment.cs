﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


        // Payment.cs

        // Payment class

        // Created by: Marcus Jones
        // Date Created: 4 / 26 / 23
        // Last Modified: 4 / 27 / 23
        // Assignment / Project: Budget App
        // Part of: Payment


namespace Budget_App.App_Code
{
    // payment class
    [Serializable]
    public class Payment
    {
        // variables for cost, description, and type
        double cost;
        String description, type;

        // initiator for payment
        public Payment(double cost, String description, String type)
        {
            this.cost = cost;
            this.description = description;
            this.type = type; 
        }

        // getters and setters for each value
        void setCost(double cost)
        {
            this.cost = cost;
        }
        public double getCost()
        {
            return this.cost;
        }

        public String getDescription()
        {
            return this.description;
        }

        public void setDescription(String description)
        {
            this.description = description;
        }
        public String getType()
        {
            return this.type;
        }

       public void setType(String type)
        {
            this.type = type;
        }

        
        // overrides ToString method to print the payment object
        override public String ToString()
        {
            String s = "Type: " + this.type + "&emsp;|&emsp;Price: $" + String.Format("{0:0.##}", this.cost) + "&emsp;|&emsp;" + this.description;
            return s;
        }

    }
}