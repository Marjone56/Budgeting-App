﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

// About.aspx.cs

// Does nothing

// Created by: Marcus Jones
// Date Created: 4 / 26 / 23
// Last Modified: 4 / 27 / 23
// Assignment / Project: Budget App
// Part of: About

namespace Budget_App.ContentPages
{
    public partial class About : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}