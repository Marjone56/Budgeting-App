﻿using Budget_App.App_Code;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

// Budget.aspx.cs

// Budget code behind

// Created by: Marcus Jones
// Date Created: 4 / 25 / 23
// Last Modified: 4 / 27 / 23
// Assignment / Project: Budget App
// Part of: Budget

namespace Budget_App.ContentPages
{
    public partial class Budget : System.Web.UI.Page
    {
        // create global list of payments
        List<Payment> sortedPayments = new List<Payment>();
        double salary = 0; double priceTotal = 0; double moneyLeft = 0;

        public List<Payment> payments
        {
            get
            {
                // get view state of list (to save when page is reloaded).
                if (!(ViewState["payments"] is List<Payment>))
                {
                    ViewState["payments"] = new List<Payment>();
                }

                return (List<Payment>)ViewState["payments"];
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            updateMoney();
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            pnlPayment.Visible = true;
        }

        protected void btnAddPayment_Click(object sender, EventArgs e)
        {
            // varibales to check for errors in input
            Boolean error = false;
            String strError = "";
            // checks for empty fields
            if (txtDescription.Text == String.Empty)
            {
                strError += "Description Field is Empty";
                error = true;
            }

            if (txtPrice.Text == String.Empty)
            {
                if (error)
                    strError += "<br>";
                strError += "Price Field is Empty";
                error = true;
            }
            if (!error)
            {
                // get values from drpdown and txtbox
                String type = drpType.Text;
                String description = txtDescription.Text;
                double cost;
                // try catch to get invalid input
                try
                {
                    cost = Convert.ToDouble(txtPrice.Text);
                } catch (Exception exception)
                {
                    lblErrors.Text = "Invalid Price Type, Please enter a $XX.XX Value";
                    return;
                }
                // create payment object
                Payment payment = new Payment(cost, description, type);
                // insert payment in list
                payments.Add(payment);

                // call payment to string
                paymentToString(payments);

                // set old text boxes to empty
                drpType.Text = "Other";
                txtDescription.Text = String.Empty;
                txtPrice.Text = String.Empty;

                // set panel to invisible
                pnlPayment.Visible = false;
                updateMoney();
                lblErrors.Text = String.Empty;
            } else
            {
                lblErrors.Text = strError;
            }
        }

        // creates string with info and sets lbl as that.
        public void paymentToString(List<Payment> paymentList)
        {
            String s = "";

            for (int i = 0; i < paymentList.Count; i++)
            {
                s += "ID: " + i + "&emsp;|&emsp;";
                s += paymentList[i].ToString();
                s += "<br>";
            }

            // set label to string
            lblPaymentOutput.Text = s;
        }

        // deletes payment at specific id number
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            // get text and convert to int
            String delete = txtDelete.Text;
            int deletion;

            // check if input is an int
            try
            {
              deletion = Int32.Parse(delete);
            } catch (Exception exception)
            {
                lblErrors.Text = "Invalid ID format, please enter an Integer";
                return;
            }

            // if id number is not valid do nothing and send error
            if (deletion < 0 || deletion > payments.Count - 1)
            {
                // set error
                txtDelete.Text = String.Empty;
                lblErrors.Text = "ID is not valid.";
            } else if (txtDelete.Text == String.Empty)
            {
                // do nothing
            }
            else
            {
                // delete in list and set txt to empty
                lblErrors.Text = String.Empty;
                payments.RemoveAt(deletion);
                paymentToString(payments);
                txtDelete.Text = String.Empty;
                updateMoney();
            }
        }

        // cancel button empties all boxes and makes panel invisible
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            drpType.Text = "Other";
            txtDescription.Text = String.Empty;
            txtPrice.Text = String.Empty;

            pnlPayment.Visible = false;
        }

        // updates money left
        public void updateMoney()
        {
            priceTotal = 0;
            // if no salary is entered, do not show anything otherwise do stuff
            if (!(lblSalary.Text == String.Empty))
            {
                // get salary from txtbox
                String strSalary = lblSalary.Text;
                // check for invalid type
                try
                {
                    salary = Convert.ToInt32(strSalary);
                } catch (Exception exception)
                {
                    lblErrors.Text = "Salary is not in Correct Format";
                    return;
                }
                if (payments.Count != 0)
                {
                    // for every payment, calculate how much the total price is
                    for (int i = 0; i < payments.Count; i++)
                    {
                        priceTotal += payments[i].getCost();
                    }
                }
            } 
            // calculate money left over and set label
            moneyLeft = (salary - priceTotal) / 12;
            lblMoneyLeft.Text = "$" + String.Format("{0:0.##}", moneyLeft);

            // set color of lblMoneyLeft based on how much money is left.
            if (moneyLeft > 0)
            {
                lblMoneyLeft.ForeColor = Color.Green;
            }
            else if (moneyLeft == 0)
            {
                lblMoneyLeft.ForeColor = Color.Black;
            }
            else
            {
                lblMoneyLeft.ForeColor = Color.Red;
            }
        }

        // if text is changed then update money
        protected void lblSalary_TextChanged(object sender, EventArgs e)
        {
            updateMoney();
        }

        protected void btnEnter_Click(object sender, EventArgs e)
        {

        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            // check if salary txt is empty
            if (lblSalary.Text == String.Empty)
            {
                lblErrors.Text = "Salary Field is Empty";
            } else // write data to txt file
            {
                String txt = "Salary: $" + String.Format("{0:0.##}", salary) + "\n\n";

                for (int i = 0; i < payments.Count; i++)
                {
                    txt += "Type: " + payments[i].getType() + " | Price: $" + String.Format("{0:0.##}", payments[i].getCost()) + " | " + payments[i].getDescription() + "\n";
                }

                txt += "\n\n";
                txt += "Money Left Per Month: $" + String.Format("{0:0.##}", moneyLeft);

                // YOU WILL NEED TO CHANGE THIS HARD CODED FILE TO WHEREEVER IT IS IN YOUR SYSTEM. NOTE THE README FILE
                using (System.IO.StreamWriter file = new System.IO.StreamWriter(@"C:\Budget App\Budget App\App_Data\BudgetFile.txt", true))
                {
                    file.WriteLine(txt);
                }

                Response.ContentType = "txt";
                Response.AppendHeader("Content-Disposition", "attachment; filename=BudgetFile.txt");
                Response.TransmitFile(Server.MapPath("~/App_Data/BudgetFile.txt"));
                Response.End();
            }
        }
    }
}