﻿Running this project is very simple, you will need to manipulate only one bit of the code. 
Within the Budget.aspx.cs file and the btnExport_Click function, I have had to hard code the BudgetFile.txt file. This location may be different for your system,
so change the location of the file depending on where it is located in your system.

All other functions of the web page should work without issue. Thanks.